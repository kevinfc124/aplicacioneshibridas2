import React from 'react'

const PeliculaActualizada = () => {
  return (
    <div>PeliculaActualizada</div>
  )
}

export default PeliculaActualizada